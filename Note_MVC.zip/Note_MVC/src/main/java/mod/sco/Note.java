public class Note {

    private int id_note;
    private String num_Ins;
    private String matiere;
    private float note;

    
    public Note() {
        this.id_note = 0;
        this.num_Ins = "";
        this.matiere = "";
        this.note = 0.0f;
    }

    public Note(int id_note, String num_Ins, String matiere, float note) {
        this.id_note = id_note;
        this.num_Ins = num_Ins;
        this.matiere = matiere;
        this.note = note;
    }

    public int getId_note() {
        return id_note;
    }

    public void setId_note(int id_note) {
        this.id_note = id_note;
    }

    public String getNum_Ins() {
        return num_Ins;
    }

    public void setNum_Ins(String num_Ins) {
        this.num_Ins = num_Ins;
    }

    public String getMatiere() {
        return matiere;
    }

    public void setMatiere(String matiere) {
        this.matiere = matiere;
    }

    public float getNote() {
        return note;
    }

    public void setNote(float note) {
        this.note = note;
    }

}
