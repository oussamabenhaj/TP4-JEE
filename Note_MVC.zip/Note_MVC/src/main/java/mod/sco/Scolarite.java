import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Vector;

public class Scolarite {
    private Connection conn;

    public Scolarite(Connection conn) {
        this.conn = conn;
    }

    public Vector<String> getNotes(String num_Ins) {
        Vector<String> notes = new Vector<>();
        try {
            String sql = "SELECT Note FROM notes WHERE Num_Ins = ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, num_Ins);

            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                String note = rs.getString("note");
                notes.add(note);
            }

            rs.close();
            stmt.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return notes;
    }

   
    }

