package form.beans;

import java.util.Vector;

public class NoteForm {
    private String numInscription;
    private Vector<String> notes;

    public String getNumInscription() {
        return numInscription;
    }

    public void setNumInscription(String numInscription) {
        this.numInscription = numInscription;
    }

    public Vector<String> getNotes() {
        return notes;
    }

    public void setNotes(Vector<String> notes) {
        this.notes = notes;
    }
}
