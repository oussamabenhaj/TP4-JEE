package metier;


public interface Iimcmetier{
	public double  calculerImc(int poid,double taille);
}

